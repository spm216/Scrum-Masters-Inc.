# Scrum-Masters-Inc.
Shane Mulcahy is cool
Ian Weiss is not
Steve Cuzzi
